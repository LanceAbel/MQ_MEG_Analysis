function help_cogent
% HELP_COGENT lists one-line help on all Cogent functions.
%
% Cogent 2000 function.
%
% $Rev: 218 $ $Date: 2010-10-27 12:06:55 +0100 (Wed, 27 Oct 2010) $

disp('COGENT 2000 COMMANDS:');
lookfor 'Cogent 2000' -all